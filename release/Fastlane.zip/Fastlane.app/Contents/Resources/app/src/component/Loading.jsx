/* eslint-disable */
import React from 'react';

export default () => (
  <div className="loading-pulse">
    <div className="pulse"></div>
  </div>
);
